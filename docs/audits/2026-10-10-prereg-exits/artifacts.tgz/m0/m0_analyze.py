import json, sys, numpy as np
from pathlib import Path
D = Path(__file__).parent
def rank(a):
    order = np.argsort(a, kind="mergesort"); r = np.empty(len(a)); i = 0
    s = np.asarray(a)[order]
    while i < len(a):
        j = i
        while j + 1 < len(a) and s[j + 1] == s[i]: j += 1
        r[order[i:j + 1]] = (i + j) / 2.0 + 1; i = j + 1
    return r
def spearman(x, y):
    rx, ry = rank(x), rank(y)
    return float(np.corrcoef(rx, ry)[0, 1])
rows = []
for w in ("AYI", "YATAY", "BOGA"):
    d = json.load(open(D / f"B0_{w}.json"))
    for t in d["trades"]:
        e, st, lev = t["entry_price"], t["stop_price"], t["leverage"]
        stop_roi = abs(e - st) / e * lev * 100.0
        rows.append((w, t["score"], t["mfe_pct"] / stop_roi, stop_roi, t["pnl"], t["exit_reason"]))
sc = np.array([r[1] for r in rows]); mfe = np.array([r[2] for r in rows])
n = len(rows); rho = spearman(sc, mfe)
rng = np.random.default_rng(20261010); K = 200000
ry = rank(mfe); rx = rank(sc); cnt = 0
for _ in range(K):
    if np.corrcoef(rx, rng.permutation(ry))[0, 1] >= rho: cnt += 1
p = (cnt + 1) / (K + 1)
q1, q2 = np.quantile(sc, [1 / 3, 2 / 3])
tid = np.where(sc <= q1, 0, np.where(sc <= q2, 1, 2))
tm = [float(mfe[tid == k].mean()) for k in range(3)]; tn = [int((tid == k).sum()) for k in range(3)]
tmed = [float(np.median(mfe[tid == k])) for k in range(3)]
mono = tm[0] < tm[1] < tm[2]
ok = rho >= 0.10 and p < 0.05 and mono
per = {}
for w in ("AYI", "YATAY", "BOGA"):
    idx = [i for i, r in enumerate(rows) if r[0] == w]
    per[w] = dict(n=len(idx), rho=spearman(sc[idx], mfe[idx]))
res = dict(n=n, rho=rho, p_one_sided=p, perms=K, q1=float(q1), q2=float(q2), tercile_mean_mfe_r=tm,
           tercile_median_mfe_r=tmed, tercile_n=tn, monotonic=mono, passed=ok, per_window=per,
           stop_roi_min=float(min(r[3] for r in rows)), stop_roi_med=float(np.median([r[3] for r in rows])),
           stop_roi_max=float(max(r[3] for r in rows)), score_min=float(sc.min()), score_med=float(np.median(sc)), score_max=float(sc.max()))
json.dump(res, open(D / "m0_result.json", "w"), indent=1)
print(json.dumps(res, indent=1))
