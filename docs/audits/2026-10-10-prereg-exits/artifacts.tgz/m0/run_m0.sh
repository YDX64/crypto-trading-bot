#!/bin/bash
# M0: B0 env (override yok), wt-code, 3 DEV penceresi, SIRALI. Çıktı: m0/ altı.
set -u
SP=/tmp/claude-0/-home-user-crypto-trading-bot/b53b3a36-e126-5de6-b27f-ca558d8408f8/scratchpad
WT=$SP/wt-code; ENVF=$SP/server-scalper-env.txt; CACHE=/home/user/crypto-trading-bot/data/klines_cache
PY=/home/user/crypto-trading-bot/.venv/bin/python
SYMS=BTCUSDT,ETHUSDT,SOLUSDT,XRPUSDT,DOGEUSDT,BNBUSDT,ADAUSDT,LTCUSDT
OUT=$SP/prereg/m0
declare -A WIN=( [AYI]="2026-01-23 2026-02-13" [YATAY]="2026-07-01 2026-07-21" [BOGA]="2026-08-07 2026-08-21" )
for w in AYI YATAY BOGA; do
  set -- ${WIN[$w]}
  sleep 1.2
  ( cd $WT && env $(grep -E '^SCALPER_' $ENVF | xargs) $PY -m src.strategies.scalper.backtest \
      --strategies C --symbols $SYMS --start $1 --end $2 --cache-dir $CACHE ) > $OUT/B0_$w.log 2>&1
  f=$(grep -oE 'logs/backtest_[0-9_]+\.json' $OUT/B0_$w.log | tail -1)
  if [ -n "$f" ] && [ -f "$WT/$f" ]; then cp "$WT/$f" $OUT/B0_$w.json; echo "OK $w $f"; else echo "HATA $w"; tail -3 $OUT/B0_$w.log; fi
done
echo BITTI
